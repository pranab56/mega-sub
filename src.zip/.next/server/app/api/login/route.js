/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/login/route";
exports.ids = ["app/api/login/route"];
exports.modules = {

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("mongodb");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.js&appDir=D%3A%5Ccloud-sub%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5Ccloud-sub&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.js&appDir=D%3A%5Ccloud-sub%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5Ccloud-sub&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var D_cloud_sub_src_app_api_login_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/login/route.js */ \"(rsc)/./src/app/api/login/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/login/route\",\n        pathname: \"/api/login\",\n        filename: \"route\",\n        bundlePath: \"app/api/login/route\"\n    },\n    resolvedPagePath: \"D:\\\\cloud-sub\\\\src\\\\app\\\\api\\\\login\\\\route.js\",\n    nextConfigOutput,\n    userland: D_cloud_sub_src_app_api_login_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZsb2dpbiUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGbG9naW4lMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZsb2dpbiUyRnJvdXRlLmpzJmFwcERpcj1EJTNBJTVDY2xvdWQtc3ViJTVDc3JjJTVDYXBwJnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMmcm9vdERpcj1EJTNBJTVDY2xvdWQtc3ViJmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUErRjtBQUN2QztBQUNxQjtBQUNIO0FBQzFFO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJEOlxcXFxjbG91ZC1zdWJcXFxcc3JjXFxcXGFwcFxcXFxhcGlcXFxcbG9naW5cXFxccm91dGUuanNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2xvZ2luL3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvbG9naW5cIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL2xvZ2luL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiRDpcXFxcY2xvdWQtc3ViXFxcXHNyY1xcXFxhcHBcXFxcYXBpXFxcXGxvZ2luXFxcXHJvdXRlLmpzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgd29ya0FzeW5jU3RvcmFnZSxcbiAgICAgICAgd29ya1VuaXRBc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.js&appDir=D%3A%5Ccloud-sub%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5Ccloud-sub&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/login/route.js":
/*!************************************!*\
  !*** ./src/app/api/login/route.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PATCH: () => (/* binding */ PATCH),\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);\n\n(__webpack_require__(/*! dotenv */ \"(rsc)/./node_modules/dotenv/lib/main.js\").config)();\nconst uri = process.env.MONGODB_URI;\nconst client = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(uri);\nasync function connectToDatabase() {\n    if (!client.topology || !client.topology.isConnected()) {\n        await client.connect();\n    }\n    return client.db('cloud'); // Replace with your database name\n}\n// POST method for initial login\nasync function POST(req) {\n    try {\n        const body = await req.json(); // Parse the incoming request body\n        console.log(body);\n        const db = await connectToDatabase();\n        const collection = db.collection('mega_personal_login'); // Replace with your collection name\n        const result = await collection.insertOne(body);\n        return new Response(JSON.stringify({\n            success: true,\n            message: 'Object successfully posted to the database.',\n            data: result\n        }), {\n            status: 201\n        });\n    } catch (error) {\n        console.error('Error posting object:', error.message);\n        return new Response(JSON.stringify({\n            success: false,\n            message: 'Failed to post the object to the database.'\n        }), {\n            status: 500\n        });\n    }\n}\n// PATCH method for OTP verification\nasync function PATCH(req) {\n    try {\n        const body = await req.json();\n        const { id, otp } = body;\n        if (!id || !otp) {\n            return new Response(JSON.stringify({\n                success: false,\n                message: 'ID and OTP are required.'\n            }), {\n                status: 400\n            });\n        }\n        const db = await connectToDatabase();\n        const collection = db.collection('mega_personal_login');\n        // Update the document with the provided ID by adding the OTP field\n        const result = await collection.updateOne({\n            _id: new mongodb__WEBPACK_IMPORTED_MODULE_0__.ObjectId(id)\n        }, {\n            $set: {\n                otp: otp,\n                otpVerifiedAt: new Date()\n            }\n        });\n        if (result.matchedCount === 0) {\n            return new Response(JSON.stringify({\n                success: false,\n                message: 'No record found with the provided ID.'\n            }), {\n                status: 404\n            });\n        }\n        if (result.modifiedCount === 0) {\n            return new Response(JSON.stringify({\n                success: false,\n                message: 'Failed to update the record.'\n            }), {\n                status: 400\n            });\n        }\n        return new Response(JSON.stringify({\n            success: true,\n            message: 'OTP successfully added to the record.',\n            data: {\n                matchedCount: result.matchedCount,\n                modifiedCount: result.modifiedCount\n            }\n        }), {\n            status: 200\n        });\n    } catch (error) {\n        console.error('Error updating object:', error.message);\n        return new Response(JSON.stringify({\n            success: false,\n            message: 'Failed to update the object in the database.',\n            error: error.message\n        }), {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9sb2dpbi9yb3V0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWdEO0FBQ2hERSxxRkFBd0I7QUFFeEIsTUFBTUUsTUFBTUMsUUFBUUMsR0FBRyxDQUFDQyxXQUFXO0FBQ25DLE1BQU1DLFNBQVMsSUFBSVIsZ0RBQVdBLENBQUNJO0FBRS9CLGVBQWVLO0lBQ2IsSUFBSSxDQUFDRCxPQUFPRSxRQUFRLElBQUksQ0FBQ0YsT0FBT0UsUUFBUSxDQUFDQyxXQUFXLElBQUk7UUFDdEQsTUFBTUgsT0FBT0ksT0FBTztJQUN0QjtJQUNBLE9BQU9KLE9BQU9LLEVBQUUsQ0FBQyxVQUFVLGtDQUFrQztBQUMvRDtBQUVBLGdDQUFnQztBQUN6QixlQUFlQyxLQUFLQyxHQUFHO0lBQzVCLElBQUk7UUFDRixNQUFNQyxPQUFPLE1BQU1ELElBQUlFLElBQUksSUFBSSxrQ0FBa0M7UUFFakVDLFFBQVFDLEdBQUcsQ0FBQ0g7UUFFWixNQUFNSCxLQUFLLE1BQU1KO1FBQ2pCLE1BQU1XLGFBQWFQLEdBQUdPLFVBQVUsQ0FBQyx3QkFBd0Isb0NBQW9DO1FBRTdGLE1BQU1DLFNBQVMsTUFBTUQsV0FBV0UsU0FBUyxDQUFDTjtRQUUxQyxPQUFPLElBQUlPLFNBQ1RDLEtBQUtDLFNBQVMsQ0FBQztZQUNiQyxTQUFTO1lBQ1RDLFNBQVM7WUFDVEMsTUFBTVA7UUFDUixJQUNBO1lBQUVRLFFBQVE7UUFBSTtJQUVsQixFQUFFLE9BQU9DLE9BQU87UUFDZFosUUFBUVksS0FBSyxDQUFDLHlCQUF5QkEsTUFBTUgsT0FBTztRQUNwRCxPQUFPLElBQUlKLFNBQ1RDLEtBQUtDLFNBQVMsQ0FBQztZQUNiQyxTQUFTO1lBQ1RDLFNBQVM7UUFDWCxJQUNBO1lBQUVFLFFBQVE7UUFBSTtJQUVsQjtBQUNGO0FBRUEsb0NBQW9DO0FBQzdCLGVBQWVFLE1BQU1oQixHQUFHO0lBQzdCLElBQUk7UUFDRixNQUFNQyxPQUFPLE1BQU1ELElBQUlFLElBQUk7UUFDM0IsTUFBTSxFQUFFZSxFQUFFLEVBQUVDLEdBQUcsRUFBRSxHQUFHakI7UUFFcEIsSUFBSSxDQUFDZ0IsTUFBTSxDQUFDQyxLQUFLO1lBQ2YsT0FBTyxJQUFJVixTQUNUQyxLQUFLQyxTQUFTLENBQUM7Z0JBQ2JDLFNBQVM7Z0JBQ1RDLFNBQVM7WUFDWCxJQUNBO2dCQUFFRSxRQUFRO1lBQUk7UUFFbEI7UUFFQSxNQUFNaEIsS0FBSyxNQUFNSjtRQUNqQixNQUFNVyxhQUFhUCxHQUFHTyxVQUFVLENBQUM7UUFFakMsbUVBQW1FO1FBQ25FLE1BQU1DLFNBQVMsTUFBTUQsV0FBV2MsU0FBUyxDQUN2QztZQUFFQyxLQUFLLElBQUlsQyw2Q0FBUUEsQ0FBQytCO1FBQUksR0FDeEI7WUFDRUksTUFBTTtnQkFDSkgsS0FBS0E7Z0JBQ0xJLGVBQWUsSUFBSUM7WUFDckI7UUFDRjtRQUdGLElBQUlqQixPQUFPa0IsWUFBWSxLQUFLLEdBQUc7WUFDN0IsT0FBTyxJQUFJaEIsU0FDVEMsS0FBS0MsU0FBUyxDQUFDO2dCQUNiQyxTQUFTO2dCQUNUQyxTQUFTO1lBQ1gsSUFDQTtnQkFBRUUsUUFBUTtZQUFJO1FBRWxCO1FBRUEsSUFBSVIsT0FBT21CLGFBQWEsS0FBSyxHQUFHO1lBQzlCLE9BQU8sSUFBSWpCLFNBQ1RDLEtBQUtDLFNBQVMsQ0FBQztnQkFDYkMsU0FBUztnQkFDVEMsU0FBUztZQUNYLElBQ0E7Z0JBQUVFLFFBQVE7WUFBSTtRQUVsQjtRQUVBLE9BQU8sSUFBSU4sU0FDVEMsS0FBS0MsU0FBUyxDQUFDO1lBQ2JDLFNBQVM7WUFDVEMsU0FBUztZQUNUQyxNQUFNO2dCQUNKVyxjQUFjbEIsT0FBT2tCLFlBQVk7Z0JBQ2pDQyxlQUFlbkIsT0FBT21CLGFBQWE7WUFDckM7UUFDRixJQUNBO1lBQUVYLFFBQVE7UUFBSTtJQUVsQixFQUFFLE9BQU9DLE9BQU87UUFDZFosUUFBUVksS0FBSyxDQUFDLDBCQUEwQkEsTUFBTUgsT0FBTztRQUNyRCxPQUFPLElBQUlKLFNBQ1RDLEtBQUtDLFNBQVMsQ0FBQztZQUNiQyxTQUFTO1lBQ1RDLFNBQVM7WUFDVEcsT0FBT0EsTUFBTUgsT0FBTztRQUN0QixJQUNBO1lBQUVFLFFBQVE7UUFBSTtJQUVsQjtBQUNGIiwic291cmNlcyI6WyJEOlxcY2xvdWQtc3ViXFxzcmNcXGFwcFxcYXBpXFxsb2dpblxccm91dGUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ29DbGllbnQsIE9iamVjdElkIH0gZnJvbSAnbW9uZ29kYic7XHJcbnJlcXVpcmUoJ2RvdGVudicpLmNvbmZpZygpO1xyXG5cclxuY29uc3QgdXJpID0gcHJvY2Vzcy5lbnYuTU9OR09EQl9VUkk7XHJcbmNvbnN0IGNsaWVudCA9IG5ldyBNb25nb0NsaWVudCh1cmkpO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gY29ubmVjdFRvRGF0YWJhc2UoKSB7XHJcbiAgaWYgKCFjbGllbnQudG9wb2xvZ3kgfHwgIWNsaWVudC50b3BvbG9neS5pc0Nvbm5lY3RlZCgpKSB7XHJcbiAgICBhd2FpdCBjbGllbnQuY29ubmVjdCgpO1xyXG4gIH1cclxuICByZXR1cm4gY2xpZW50LmRiKCdjbG91ZCcpOyAvLyBSZXBsYWNlIHdpdGggeW91ciBkYXRhYmFzZSBuYW1lXHJcbn1cclxuXHJcbi8vIFBPU1QgbWV0aG9kIGZvciBpbml0aWFsIGxvZ2luXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTsgLy8gUGFyc2UgdGhlIGluY29taW5nIHJlcXVlc3QgYm9keVxyXG5cclxuICAgIGNvbnNvbGUubG9nKGJvZHkpO1xyXG5cclxuICAgIGNvbnN0IGRiID0gYXdhaXQgY29ubmVjdFRvRGF0YWJhc2UoKTtcclxuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKCdtZWdhX3BlcnNvbmFsX2xvZ2luJyk7IC8vIFJlcGxhY2Ugd2l0aCB5b3VyIGNvbGxlY3Rpb24gbmFtZVxyXG5cclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbGxlY3Rpb24uaW5zZXJ0T25lKGJvZHkpO1xyXG5cclxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICBzdWNjZXNzOiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6ICdPYmplY3Qgc3VjY2Vzc2Z1bGx5IHBvc3RlZCB0byB0aGUgZGF0YWJhc2UuJyxcclxuICAgICAgICBkYXRhOiByZXN1bHQsXHJcbiAgICAgIH0pLFxyXG4gICAgICB7IHN0YXR1czogMjAxIH1cclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHBvc3Rpbmcgb2JqZWN0OicsIGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6ICdGYWlsZWQgdG8gcG9zdCB0aGUgb2JqZWN0IHRvIHRoZSBkYXRhYmFzZS4nLFxyXG4gICAgICB9KSxcclxuICAgICAgeyBzdGF0dXM6IDUwMCB9XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuLy8gUEFUQ0ggbWV0aG9kIGZvciBPVFAgdmVyaWZpY2F0aW9uXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQQVRDSChyZXEpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcS5qc29uKCk7XHJcbiAgICBjb25zdCB7IGlkLCBvdHAgfSA9IGJvZHk7XHJcblxyXG4gICAgaWYgKCFpZCB8fCAhb3RwKSB7XHJcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnSUQgYW5kIE9UUCBhcmUgcmVxdWlyZWQuJyxcclxuICAgICAgICB9KSxcclxuICAgICAgICB7IHN0YXR1czogNDAwIH1cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBkYiA9IGF3YWl0IGNvbm5lY3RUb0RhdGFiYXNlKCk7XHJcbiAgICBjb25zdCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbignbWVnYV9wZXJzb25hbF9sb2dpbicpO1xyXG5cclxuICAgIC8vIFVwZGF0ZSB0aGUgZG9jdW1lbnQgd2l0aCB0aGUgcHJvdmlkZWQgSUQgYnkgYWRkaW5nIHRoZSBPVFAgZmllbGRcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbGxlY3Rpb24udXBkYXRlT25lKFxyXG4gICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgb3RwOiBvdHAsXHJcbiAgICAgICAgICBvdHBWZXJpZmllZEF0OiBuZXcgRGF0ZSgpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIGlmIChyZXN1bHQubWF0Y2hlZENvdW50ID09PSAwKSB7XHJcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnTm8gcmVjb3JkIGZvdW5kIHdpdGggdGhlIHByb3ZpZGVkIElELicsXHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgeyBzdGF0dXM6IDQwNCB9XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHJlc3VsdC5tb2RpZmllZENvdW50ID09PSAwKSB7XHJcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnRmFpbGVkIHRvIHVwZGF0ZSB0aGUgcmVjb3JkLicsXHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgeyBzdGF0dXM6IDQwMCB9XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogJ09UUCBzdWNjZXNzZnVsbHkgYWRkZWQgdG8gdGhlIHJlY29yZC4nLFxyXG4gICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgIG1hdGNoZWRDb3VudDogcmVzdWx0Lm1hdGNoZWRDb3VudCxcclxuICAgICAgICAgIG1vZGlmaWVkQ291bnQ6IHJlc3VsdC5tb2RpZmllZENvdW50XHJcbiAgICAgICAgfSxcclxuICAgICAgfSksXHJcbiAgICAgIHsgc3RhdHVzOiAyMDAgfVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgdXBkYXRpbmcgb2JqZWN0OicsIGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6ICdGYWlsZWQgdG8gdXBkYXRlIHRoZSBvYmplY3QgaW4gdGhlIGRhdGFiYXNlLicsXHJcbiAgICAgICAgZXJyb3I6IGVycm9yLm1lc3NhZ2UsXHJcbiAgICAgIH0pLFxyXG4gICAgICB7IHN0YXR1czogNTAwIH1cclxuICAgICk7XHJcbiAgfVxyXG59Il0sIm5hbWVzIjpbIk1vbmdvQ2xpZW50IiwiT2JqZWN0SWQiLCJyZXF1aXJlIiwiY29uZmlnIiwidXJpIiwicHJvY2VzcyIsImVudiIsIk1PTkdPREJfVVJJIiwiY2xpZW50IiwiY29ubmVjdFRvRGF0YWJhc2UiLCJ0b3BvbG9neSIsImlzQ29ubmVjdGVkIiwiY29ubmVjdCIsImRiIiwiUE9TVCIsInJlcSIsImJvZHkiLCJqc29uIiwiY29uc29sZSIsImxvZyIsImNvbGxlY3Rpb24iLCJyZXN1bHQiLCJpbnNlcnRPbmUiLCJSZXNwb25zZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJzdWNjZXNzIiwibWVzc2FnZSIsImRhdGEiLCJzdGF0dXMiLCJlcnJvciIsIlBBVENIIiwiaWQiLCJvdHAiLCJ1cGRhdGVPbmUiLCJfaWQiLCIkc2V0Iiwib3RwVmVyaWZpZWRBdCIsIkRhdGUiLCJtYXRjaGVkQ291bnQiLCJtb2RpZmllZENvdW50Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/login/route.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/dotenv"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.js&appDir=D%3A%5Ccloud-sub%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5Ccloud-sub&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();